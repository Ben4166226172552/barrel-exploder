let gameState = "menu";
let score = 0;
let timer = 30;
let startTimeValue = 0;

let barrels = [];
let targets = [];
let falling = [];
let popups = [];

let chainMode = false;

// --- NEU: SPAWN-DELAY VARIABLEN ---
let spawnTimer = 0;
const SPAWN_DELAY = 12; // Wartezeit in Frames (ca. 0.2 Sek bei 60fps)

// --- HIGHSCORE SPEICHER ---
let highscores = {
  "classic_normal": 0,
  "classic_chain": 0,
  "target": 0,
  "falling": 0,
  "time": 0
};

// --- PAUSE LOGIK ---
let isPaused = false;
let pauseStartTime = 0;

// --- COUNTDOWN LOGIK ---
let timeCountdownActive = false;
let countdownStartTime = 0;

// --- EFFEKTE & HINTERGRUND ---
let bgHue = 220;
let rainbowTimer = 0;
let lastMilestone = 0;

/* ================= SETUP ================= */

function setup() {
  createCanvas(windowWidth, windowHeight);
  textFont("Arial");
  
  for (let mode in highscores) {
    let saved = localStorage.getItem("barrelScore_" + mode);
    if (saved !== null) {
      highscores[mode] = parseInt(saved);
    }
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

/* ================= LOGIK-KERN ================= */

function getCurrentModeKey() {
  if (gameState === "classic") return chainMode ? "classic_chain" : "classic_normal";
  if (gameState === "target") return "target";
  if (gameState === "falling") return "falling";
  if (gameState === "time") return "time";
  return null;
}

function checkAndSaveHighscore() {
  let key = getCurrentModeKey();
  if (key && score > highscores[key]) {
    highscores[key] = score;
    localStorage.setItem("barrelScore_" + key, score);
  }
}

/* ================= DRAW ================= */

function draw() {
  handleBackground();

  if (gameState === "menu") {
    drawMenu();
  } else if (gameState === "classic_select") {
    drawClassicSelect();
  } else if (gameState === "classic") {
    drawClassic();
  } else if (gameState === "target") {
    drawTarget();
  } else if (gameState === "falling") {
    drawFalling();
  } else if (gameState === "time") {
    drawTime();
  }

  for (let i = popups.length - 1; i >= 0; i--) {
    if (!isPaused) popups[i].update();
    popups[i].show();
    if (popups[i].life <= 0) popups.splice(i, 1);
  }

  if (gameState !== "menu" && gameState !== "classic_select") {
    drawTopUI();
  }
  drawCredits();

  if (isPaused) {
    drawPauseMenu();
  }
}

/* ================= HINTERGRUND & EFFEKTE ================= */

function handleBackground() {
  colorMode(HSB, 360, 100, 100);
  if (rainbowTimer > 0) {
    if (!isPaused) rainbowTimer--;
    background((frameCount * 8) % 360, 50, 25); 
    textAlign(CENTER, CENTER);
    fill(0, 0, 100, map(rainbowTimer, 0, 100, 0, 255)); 
    textSize(120); 
    textStyle(BOLD);
    text(lastMilestone, width/2, height/2);
    textStyle(NORMAL);
  } else {
    background(bgHue, 40, 15); 
  }
  colorMode(RGB, 255);
}

function checkMilestone() {
  let currentMilestoneStep = floor(score / 100) * 100;
  if (currentMilestoneStep > lastMilestone && currentMilestoneStep > 0) {
    rainbowTimer = 100;
    bgHue = random(360);
    lastMilestone = currentMilestoneStep;
    if (gameState === "time") {
      popups.push(new FloatingText(width/2, height/2 - 100, "+30 SEK!", color(0, 255, 100)));
    }
  }
  checkAndSaveHighscore();
}

/* ================= STEUERUNG ================= */

function mousePressed() {
  if (isPaused) {
    if (hit(width/2, height/2 + 50)) {
      isPaused = false;
      if (gameState === "time") startTimeValue += (millis() - pauseStartTime);
    }
    return;
  }

  if (gameState !== "menu" && gameState !== "classic_select") {
    if (mouseX > width - 120 && mouseX < width - 20 && mouseY > 12 && mouseY < 48) {
      checkAndSaveHighscore();
      resetGame();
      gameState = "menu";
      return;
    }
    if (mouseX > width - 230 && mouseX < width - 130 && mouseY > 12 && mouseY < 48) {
      if (gameState === "time" && (timer <= 0 || timeCountdownActive)) return;
      isPaused = true;
      pauseStartTime = millis();
      return;
    }
  }

  if (gameState === "menu") {
    if (hit(width/2, 270)) gameState = "classic_select"; 
    else if (hit(width/2, 360)) startTarget();
    else if (hit(width/2, 450)) startFalling();
    else if (hit(width/2, 540)) startTime();
    return;
  }

  if (gameState === "classic_select") {
    if (hit(width/2, 320)) { chainMode = false; startClassic(); }
    else if (hit(width/2, 420)) { chainMode = true; startClassic(); }
    return;
  }

  if (gameState === "time" && timer <= 0) {
    if (mouseX > width/2 - 110 && mouseX < width/2 + 110 &&
        mouseY > height/2 + 160 && mouseY < height/2 + 220) {
      startTime();
    }
    return;
  }

  if (gameState !== "menu" && gameState !== "classic_select") {
    if (gameState === "time" && timeCountdownActive) return;
    hitAll(mouseX, mouseY);
  }
}

function handleSwipe() {
  if (mouseIsPressed && !isPaused) {
    if (gameState === "time" && timeCountdownActive) return;
    
    let d = dist(pmouseX, pmouseY, mouseX, mouseY);
    if (d > 4) {
      let steps = min(ceil(d / 12), 6); 
      for (let i = 0; i <= steps; i++) {
        let checkX = lerp(pmouseX, mouseX, i / steps);
        let checkY = lerp(pmouseY, mouseY, i / steps);
        hitAll(checkX, checkY);
      }
    } else {
      hitAll(mouseX, mouseY);
    }
  }
}

function hitAll(x, y) {
  if (gameState === "target") {
    let hitSomething = false;
    for (let i = targets.length - 1; i >= 0; i--) {
      if (targets[i].hit(x, y)) { hitSomething = true; break; }
    }
    if (!hitSomething) {
      score -= 1;
      popups.push(new FloatingText(x, y, "-1", color(255, 50, 50)));
    }
  } else if (gameState === "falling") {
    for (let f of falling) { if (f.hit(x, y)) return; }
  } else {
    for (let i = barrels.length - 1; i >= 0; i--) {
       if (barrels[i].hit(x, y)) break; 
    }
  }
}

function resetGame() {
  score = 0; bgHue = 220; rainbowTimer = 0; lastMilestone = 0;
  isPaused = false; timeCountdownActive = false;
  spawnTimer = 0; // Timer zurücksetzen
  popups = []; barrels = []; targets = []; falling = [];
}

/* ================= MODI FUNKTIONEN ================= */

function startClassic(){ 
  gameState = "classic"; 
  resetGame(); 
  for (let i = 0; i < 6; i++) barrels.push(new Barrel()); 
}

function drawClassic(){
  hud(chainMode ? "Classic (Chain)" : "Classic");
  if (!isPaused) {
    checkMilestone();
    handleSwipe();
    
    barrels = barrels.filter(b => !b.isDead);
    
    // NEUE SPAWN-LOGIK MIT VERZÖGERUNG
    let activeCount = barrels.filter(b => !b.exploded).length;
    if (activeCount < 6 && spawnTimer <= 0) {
      barrels.push(new Barrel());
      spawnTimer = SPAWN_DELAY; // Setze den Cooldown
    }
    if (spawnTimer > 0) spawnTimer--; // Timer runterzählen
    
    for (let b of barrels) b.update();
  }
  for (let b of barrels) b.show();
}

function startTarget(){ gameState = "target"; resetGame(); for (let i = 0; i < 6; i++) targets.push(new Target()); }
function drawTarget(){
  hud("Target Mode");
  if (!isPaused) {
    checkMilestone();
    for (let t of targets) t.update();
  }
  for (let t of targets) t.show();
}

function startFalling(){ gameState = "falling"; resetGame(); for (let i = 0; i < 6; i++) falling.push(new Falling()); }
function drawFalling(){
  hud("Fallende Fässer");
  if (!isPaused) {
    checkMilestone();
    while (falling.length < 6) falling.push(new Falling());
    for (let f of falling) f.update();
  }
  for (let f of falling) f.show();
}

function startTime(){ 
  gameState = "time"; 
  resetGame(); 
  timer = 30; 
  timeCountdownActive = true; 
  countdownStartTime = millis(); 
  for (let i = 0; i < 6; i++) barrels.push(new Barrel()); 
}

function drawTime(){
  hud("Zeitmodus");
  
  if (timeCountdownActive) {
    for (let b of barrels) b.show();
    
    push();
    fill(0, 0, 0, 180); 
    rectMode(CENTER);
    rect(width/2, height/2, width, height);
    
    let elapsedSeconds = floor((millis() - countdownStartTime) / 1000);
    let currentCount = 3 - elapsedSeconds;
    
    if (currentCount > 0) {
      textAlign(CENTER, CENTER);
      textSize(180);
      textStyle(BOLD);
      fill(255, 215, 0); 
      text(currentCount, width/2, height/2);
    } else {
      timeCountdownActive = false;
      startTimeValue = millis(); 
    }
    pop();
    
  } else {
    if (!isPaused) {
      checkMilestone();
      if (timer > 0) {
        let elapsedSeconds = floor((millis() - startTimeValue) / 1000);
        let bonusSeconds = (lastMilestone / 100) * 30;
        timer = max(0, 30 - elapsedSeconds + bonusSeconds);
        
        barrels = barrels.filter(b => !b.isDead);
        
        // AUCH IM ZEITMODUS SPAWN-DELAY NUTZEN
        let activeCount = barrels.filter(b => !b.exploded).length;
        if (activeCount < 6 && spawnTimer <= 0) {
          barrels.push(new Barrel());
          spawnTimer = SPAWN_DELAY;
        }
        if (spawnTimer > 0) spawnTimer--;

        for (let b of barrels) b.update();
      }
    }
    
    for (let b of barrels) b.show();
    
    textAlign(CENTER); textSize(32); fill(255); text("Zeit: " + timer, width/2, 80);
    
    if (timer <= 0 && !isPaused) {
      drawGameOver();
    }
  }
}

/* ================= KLASSEN ================= */

class Barrel {
  constructor(){ 
    this.reset(); 
    this.exploded = false;
    this.isDead = false; 
    this.parts = [];
    this.flash = 0;
  }
  reset(){
    this.x = random(80, width - 80); 
    this.y = random(120, height - 120);
    this.w = 55; this.h = 110;
  }
  update(){
    if (this.exploded) {
      for (let p of this.parts) p.update();
      this.parts = this.parts.filter(p => p.life > 0);
      if (this.parts.length === 0) this.isDead = true;
    }
  }
  show(){
    if (this.exploded) { 
      if (this.flash > 0) {
        fill(255, 255, 200, this.flash); ellipse(this.x, this.y, 150, 150);
        this.flash -= 50;
      }
      for (let p of this.parts) p.show(); 
      return; 
    }
    
    rectMode(CENTER); 
    fill(180, 40, 40); 
    rect(this.x, this.y, this.w, this.h, 4); 
    
    fill(20, 25, 30); 
    rect(this.x, this.y - this.h/2 + 4, this.w + 4, 8, 2);
    rect(this.x, this.y + this.h/2 - 4, this.w + 4, 8, 2);
    rect(this.x, this.y - 20, this.w + 6, 6, 2);
    rect(this.x, this.y + 20, this.w + 6, 6, 2);

    drawBarrelDetails(this.x, this.y);
  }
  explode() {
    if (this.exploded) return;
    this.exploded = true; 
    this.flash = 255; 
    score++;
    popups.push(new FloatingText(this.x, this.y, "+1"));
    this.parts = []; for (let i = 0; i < 40; i++) this.parts.push(new Particle(this.x, this.y));
    
    if (gameState === "classic" && chainMode) {
      for (let b of barrels) {
        if (!b.exploded && dist(this.x, this.y, b.x, b.y) < 160) {
          setTimeout(() => { if(!isPaused) b.explode(); }, 100);
        }
      }
    }
  }
  hit(mx,my){
    let buffer = 15;
    if (!this.exploded && mx > this.x-this.w/2-buffer && mx < this.x+this.w/2+buffer && my > this.y-this.h/2-buffer && my < this.y+this.h/2+buffer) {
      this.explode(); 
      return true;
    }
    return false;
  }
}

class Falling {
  constructor(){ this.reset(); this.size = random(65, 90); this.exploding = false; this.explosion = []; this.flash = 0; }
  reset(){ 
    this.x = random(100, width - 100); this.y = random(-600, -100); 
    this.speed = random(3, 6) + floor(max(0, score) / 100); 
  }
  update(){
    if (this.exploding) {
      for (let p of this.explosion) p.update();
      this.explosion = this.explosion.filter(p => p.life > 0);
      if (this.explosion.length === 0) { this.exploding = false; this.reset(); }
      return;
    }
    this.y += this.speed;
    if (this.y > height + 100) { 
      score -= 2; 
      popups.push(new FloatingText(this.x, height-50, "-2", color(255, 50, 50))); 
      this.reset(); 
    }
  }
  show(){
    if (this.exploding) { 
      if (this.flash > 0) { fill(255, 255, 255, this.flash); ellipse(this.x, this.y, 180, 180); this.flash -= 40; }
      for (let p of this.explosion) p.show(); return; 
    }
    
    let w = this.size;
    let h = this.size * 1.3;
    
    rectMode(CENTER); 
    fill(180, 40, 40); 
    rect(this.x, this.y, w, h, 4);
    
    fill(20, 25, 30); 
    rect(this.x, this.y - h/2 + 4, w + 4, 8, 2);
    rect(this.x, this.y + h/2 - 4, w + 4, 8, 2);
    rect(this.x, this.y - h*0.2, w + 6, h*0.06, 2);
    rect(this.x, this.y + h*0.2, w + 6, h*0.06, 2);

    drawBarrelDetails(this.x, this.y);
  }
  hit(mx,my){
    if (!this.exploding && dist(mx,my,this.x,this.y) < this.size) {
      score += 2; popups.push(new FloatingText(this.x, this.y, "+2"));
      this.exploding = true; this.flash = 255;
      this.explosion = []; for (let i = 0; i < 40; i++) this.explosion.push(new Particle(this.x,this.y));
      return true;
    }
    return false;
  }
}

class Particle {
  constructor(x,y){ 
    this.x = x; this.y = y; let angle = random(TWO_PI); let force = random(2, 8);
    this.vx = cos(angle) * force; this.vy = sin(angle) * force; this.life = 255; this.size = random(4, 10);
    this.type = random() > 0.2 ? "fire" : "smoke";
  }
  update(){ this.x += this.vx; this.y += this.vy; this.vy += 0.15; this.vx *= 0.96; this.life -= 8; }
  show(){ 
    noStroke(); 
    if (this.type === "fire") fill(255, map(this.life, 255, 0, 255, 0), 0, this.life);
    else fill(100, 100, 100, this.life * 0.6); 
    ellipse(this.x, this.y, this.size); 
  }
}

class Target {
  constructor(){ this.x = random(80, width - 80); this.y = random(120, height - 120); this.r = 35; this.vx = random(-3, 3); this.vy = random(-3, 3); }
  update(){
    this.x += this.vx; this.y += this.vy;
    if (this.x < 50 || this.x > width - 50) this.vx *= -1;
    if (this.y < 100 || this.y > height - 50) this.vy *= -1;
  }
  show(){
    noStroke(); fill(220,40,40); ellipse(this.x,this.y,this.r*2); fill(255); ellipse(this.x,this.y,this.r*1.5);
    fill(220,40,40); ellipse(this.x,this.y,this.r); fill(255); ellipse(this.x,this.y,this.r*0.4);
  }
  hit(mx,my){
    if (dist(mx,my,this.x,this.y) < this.r) { 
      score++; popups.push(new FloatingText(this.x, this.y, "+1"));
      this.x = random(80, width - 80); this.y = random(120, height - 120); 
      return true; 
    }
    return false;
  }
}

class FloatingText {
  constructor(x, y, txt, col = color(255, 215, 0)) { this.x = x; this.y = y; this.txt = txt; this.col = col; this.life = 255; this.vy = -2; }
  update() { this.y += this.vy; this.life -= 4; }
  show() { push(); textAlign(CENTER); textSize(28); textStyle(BOLD); fill(red(this.col), green(this.col), blue(this.col), this.life); text(this.txt, this.x, this.y); pop(); }
}

/* ================= UI KOMPONENTEN ================= */

function menuBtn(x,y,t){ 
  rectMode(CENTER); fill(140,50,40); rect(x,y,340,70,15); 
  fill(255); textAlign(CENTER,CENTER); textSize(26); text(t,x,y); 
}

function hud(t){
  fill(255); textAlign(LEFT,TOP); textSize(24); text(t, 20, 20);
  fill(255, 215, 0); text("Score: " + score, 20, 50);
  let key = getCurrentModeKey();
  if (key) {
    fill(200); textSize(18);
    text("Best: " + max(score, highscores[key]), 20, 80);
  }
}

function drawTopUI(){
  rectMode(CENTER); fill(30); stroke(255); rect(width-70, 30, 100, 35, 8);
  noStroke(); fill(255); textAlign(CENTER,CENTER); textSize(14); text("🏠 HOME", width-70, 30);
  
  if (!(gameState === "time" && timer <= 0)) {
    stroke(255); fill(30); rect(width-180, 30, 100, 35, 8);
    noStroke(); fill(255); text("⏸ PAUSE", width-180, 30);
  }
}

function drawPauseMenu() {
  push();
  fill(0, 0, 0, 200); rect(width/2, height/2, width, height);
  fill(255); textAlign(CENTER, CENTER); textSize(50); text("PAUSE", width/2, height/2 - 50);
  menuBtn(width/2, height/2 + 50, "WEITER");
  pop();
}

function drawCredits(){ textAlign(RIGHT,BOTTOM); textSize(14); fill(150); text('Ersteller Ben D.', width-20,height-35); text("Mitwirkende Noah H.", width-20,height-15); }

function drawBarrelDetails(x, y) { 
  push(); 
  translate(x, y); 
  fill(255, 215, 0); 
  noStroke();
  beginShape();
  vertex(0, -22); 
  bezierVertex(12, -10, 12, 10, 0, 12); 
  bezierVertex(-12, 10, -12, -10, 0, -22);
  endShape(CLOSE);
  textAlign(CENTER, CENTER);
  fill(255, 215, 0); 
  textSize(16);
  textStyle(BOLD);
  text("OIL", 0, 24); 
  pop(); 
}

function hit(x, y){ return mouseX > x - 170 && mouseX < x + 170 && mouseY > y - 35 && mouseY < y + 35; }

function drawMenu() {
  textAlign(CENTER, CENTER); fill(255); textSize(50); text("Barrel Exploder", width/2, 100);
  fill(200); textSize(20); text("Wähle einen Modus", width/2, 160);
  menuBtn(width/2, 270, "KLASSISCH"); menuBtn(width/2, 360, "ZIELMODUS"); menuBtn(width/2, 450, "FALLENDE FÄSSER"); menuBtn(width/2, 540, "ZEITMODUS");
}

function drawClassicSelect() {
  textAlign(CENTER, CENTER); fill(255); textSize(50); text("Klassisch Modus", width/2, 100);
  menuBtn(width/2, 320, "NORMAL"); menuBtn(width/2, 420, "KETTENREAKTION");
}

function drawGameOver() {
  push();
  fill(0, 0, 0, 200); 
  rect(width/2, height/2, width, height);
  
  checkAndSaveHighscore();
  textAlign(CENTER); fill(255); textSize(48); text("ZEIT VORBEI!", width/2, height/2 - 20);
  textSize(24); text("Endstand: " + score, width/2, height/2 + 40);
  
  let key = getCurrentModeKey();
  if (key && score >= highscores[key] && score > 0) {
    fill(0, 255, 100); text("NEUER REKORD!", width/2, height/2 + 80);
  }
  
  menuBtn(width/2, height/2 + 190, "ERNEUT VERSUCHEN");
  pop();
}